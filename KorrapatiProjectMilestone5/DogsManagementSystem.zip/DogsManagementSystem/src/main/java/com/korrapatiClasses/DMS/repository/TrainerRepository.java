package com.korrapatiClasses.DMS.repository;

import org.springframework.data.repository.CrudRepository;

import com.korrapatiClasses.DMS.Models.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {

}
