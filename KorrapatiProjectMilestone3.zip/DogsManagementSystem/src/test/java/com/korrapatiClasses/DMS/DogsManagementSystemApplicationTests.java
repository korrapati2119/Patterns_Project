package com.korrapatiClasses.DMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogsManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
